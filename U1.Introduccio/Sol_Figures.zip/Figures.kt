
/* Declaració de la interfície Superficie, 
   amb el mètode calcularArea  */

   interface Superficie{
    fun calcularArea():Float
}

/* Declaració de la classe abstracta Figura, amb la 
   propietat String per al color i els mètodes
   obtenirTipus i calcularArea. 
   Utilitzarem el constructor primari, 
   pel que definirem les variables en aquest. */

abstract class Figura(val color:String):Superficie{
     abstract fun obetenirTipus():String
     override abstract fun calcularArea():Float
}

/*Classe Rectangle: 
   - Deriva de Figura, 
   - Implementa Superficie. */
    	
class Rectangle(
    val base:Float, 
    val altura:Float, 
    color:String):Figura(color) {
    
    override fun calcularArea():Float{
        return base*altura
    }

    override fun obetenirTipus():String{
        return "Rectangle"
    }
}

class Quadrat(
    val costat:Float, 
    color:String):Figura(color) {
    
    override fun calcularArea():Float{
        return costat*costat
    }

    override fun obetenirTipus():String{
        return "Quadrat"
    }
}

class Triangle(
    val base:Float, 
    val altura:Float, 
    color:String):Figura(color) {
    
    override fun calcularArea():Float{
        return (base*altura)/2
    }

    override fun obetenirTipus():String{
        return "Triangle"
    }
}

class Cercle(
    val radi:Float, 
    color:String):Figura(color) {
    
    override fun calcularArea():Float{
        return Math.PI.toFloat()*radi*radi
    }

    override fun obetenirTipus():String{
        return "Cercle"
    }
}

class Ellipse(
    val radi1:Float, 
    val radi2:Float, 
    color:String):Figura(color) {
    
    override fun calcularArea():Float{
        return Math.PI.toFloat()*radi1*radi2
    }

    override fun obetenirTipus():String{
        return "El·lipse"
    }
}



/* Funció principal */

fun main(){

    val figures: MutableList<Figura> = mutableListOf<Figura>()
    
    figures.add(Rectangle(3.0f, 2.0f, "blau"))
    figures.add(Quadrat(4.0f, "verd"))
    figures.add(Triangle(2.0f, 5.0f, "taronja"))
    figures.add(Cercle(7.0f, "roig"))
    figures.add(Ellipse(5.0f, 6.0f, "groc"))
  

    for (figura in figures){
        println("Figura: "+figura.obetenirTipus()+" de color "+figura.color+" té una superficie de "+figura.calcularArea())
    }
}

