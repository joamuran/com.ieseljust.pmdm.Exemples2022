package com.ieseljust.pmdm.contactes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.ieseljust.pmdm.contactes.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private fun itemClicked(contacte: Contacte, v: View) {
        Toast.makeText(applicationContext, "Click sobre "+contacte.name, Toast.LENGTH_SHORT).show()
    }

    private fun itemLongClicked(contacte: Contacte, v: View):Boolean {
        Toast.makeText(applicationContext, "Click llarg sobre "+contacte.name, Toast.LENGTH_SHORT).show()
        return true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        // "Unflem" els contactes amb el contingut del JSON
        Contactes.inflate(this, R.raw.contacts)

        // Associem el LayoutManager
        binding.ContactesRecyclerView.layoutManager= LinearLayoutManager(this)
        binding.ContactesRecyclerView.setHasFixedSize(true)

        //binding.ContactesRecyclerView.adapter = AdaptadorContactes()
        binding.ContactesRecyclerView.adapter = AdaptadorContactes(
            { contacte: Contacte, v: View -> itemClicked(contacte, v) },
            { contacte: Contacte, v: View -> itemLongClicked(contacte, v) }
        )


    }
}