package com.ieseljust.pmdm.contactes

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.ieseljust.pmdm.contactes.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), MyDialogFragment.OkOrCancelDialogable {

    private lateinit var binding: ActivityMainBinding

    private var contacteToRemove:Contacte?=null


    private fun itemClicked(contacte: Contacte, v: View) {
        // Creem un nou Intent per a obrir l'activitat d'edició
        // proporcionant-li el contacte sobre el qual s'ha fet clic

        val intent = Intent(this, EditaContacte::class.java).apply{
            // I li proporcionem el contacte, ja que aquest és serializable
            putExtra("com.ieseljust.pmdm.contactes.Contacte", contacte)
        }
        startActivity(intent)
    }

    private fun itemLongClicked(contacte: Contacte, v: View):Boolean {
        //Toast.makeText(applicationContext, "Click llarg sobre "+contacte.name, Toast.LENGTH_SHORT).show()

        contacteToRemove=contacte

        val myDialog = MyDialogFragment(getString(R.string.askRemoveTitle), getString(R.string.askRemove))
        myDialog.show(supportFragmentManager, "removeDialog")
        return true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        // "Unflem" els contactes amb el contingut del JSON
        Contactes.inflate(this, R.raw.contacts)

        // Associem el LayoutManager
        binding.ContactesRecyclerView.layoutManager= LinearLayoutManager(this)
        binding.ContactesRecyclerView.setHasFixedSize(true)

        binding.ContactesRecyclerView.adapter = AdaptadorContactes(
            { contacte: Contacte, v: View -> itemClicked(contacte, v) },
            { contacte: Contacte, v: View -> itemLongClicked(contacte, v) }
        )

    }

    override fun onResume() {
        super.onResume()
        // Quan la vista torna a primer pla, redibuixem el RecyclerView
        // Per si es va haver-hi modificacions en el contingut.
        binding.ContactesRecyclerView.adapter?.notifyDataSetChanged()

    }

    override fun onPositiveClick() {
        // Si es prem a Acceptar en el diàleg
        // eliminem l'item.
        contacteToRemove?.also {
            val index=Contactes.remove(it) // Recordem que aquest mètode ens tornava l'índex!

            // I actualitzem l'adaptador del RecyclerView
            // En lloc de DataSetChanged,
            // utilitzem el mètode notifyItemRemoved
            // indicant la posició eliminada. D'aquesta manera, s'aplica una
            // animació en l'esborrat.
            binding.ContactesRecyclerView.adapter?.notifyItemRemoved(index)
        }

    }

    override fun onCancelClick() {
        Toast.makeText(applicationContext, R.string.ActionCancelled, Toast.LENGTH_SHORT).show()
    }
}