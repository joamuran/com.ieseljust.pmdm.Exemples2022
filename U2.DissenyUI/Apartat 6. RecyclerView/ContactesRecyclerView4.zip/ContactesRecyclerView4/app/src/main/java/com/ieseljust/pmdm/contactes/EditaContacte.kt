package com.ieseljust.pmdm.contactes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import com.ieseljust.pmdm.contactes.databinding.ActivityEditaContacteBinding
import com.ieseljust.pmdm.contactes.databinding.ActivityMainBinding

class EditaContacte : AppCompatActivity() {

    private lateinit var binding: ActivityEditaContacteBinding

    private var contacteActual:Contacte? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityEditaContacteBinding.inflate(layoutInflater)

        setContentView(binding.root)

        // Agafem la informació de l'Intent (si existeix)
        val contacte: Contacte? = getIntent().getExtras()
            ?.getSerializable("com.ieseljust.pmdm.contactes.Contacte") as Contacte?

        contacte?.also {  // Si el contacte no és nul...

            // Actualitzem el contacte actual
            contacteActual=it

            // (En aquesta funció d'àmbit, it farà referència al propi contacte)

            // Actualitzem les vistes de la interfície
            binding.imageViewContacte.setImageResource(it.img)
            binding.editTextTextPersonName.setText(it.name)
            binding.editTextPhone.setText(it.phone)
            binding.editTextTextEmailAddress.setText(it.email)

            // Actualització de l'spinner
            // Recorrem els diferents valors d'aquest, i comparem
            // amb el valor guardat. Si coindiceix, deixem seleccionat el valor.

            for (i in 0..binding.spinnerClasse.adapter.count)
                if (binding.spinnerClasse.adapter.getItem(i).equals(it.classe)) {
                    binding.spinnerClasse.setSelection(i)
                    break
                }

        }

        // Capturem el click sobre el botó de guardar:
        binding.buttonSave.setOnClickListener {
            guardaContacte()
        }
    }

    fun guardaContacte(){
        // Creem un nou contacte a partir de la informació de les vistes
        val nou=Contacte(
            binding.editTextTextPersonName.text.toString(),
            binding.spinnerClasse.selectedItem.toString(),
            contacteActual?.img?:0, // La imatge serà la mateixa
            binding.editTextPhone.text.toString(),
            binding.editTextTextEmailAddress.text.toString())

        if (contacteActual!=null)  {
            // I  una vegada creat, reemplacem el ContacteActual per aquest
            Contactes.replace(contacteActual!!, nou)
            Snackbar.make(binding.root,
                "Contact has been modified successful",
                Snackbar.LENGTH_LONG).setAction("Close", {finish()}).show()
        } else {
            // Si el contacte actual és nul, el que farem serà afegir un
            // nou contacte
            Contactes.add(nou)
            Snackbar.make(binding.root,
                "Contact has been Added successful",
                    Snackbar.LENGTH_LONG).setAction("Close", {finish()}).show()

            // Actualitzem el contacte actual, per si ara es modifica
            contacteActual=nou
        }


    }

}